import matplotlib.pyplot as plt
import numpy as np

def calc_logistic(x, a):
    xn = a * x * (1 - x)
    return(xn)

T = 100 #Time
a = 4.0 # 0 <= a <=4
first_X = 0.3 # 0 <= x <=1
ans = []

x = np.arange(0, 1.0, (1/T))

tmp = first_X
ans.append(tmp)
for i in x:
    tmp_ans = calc_logistic(tmp, a)
    ans.append(tmp_ans)
    tmp = tmp_ans

print(ans)
plt.plot(x, x, "-b")
plt.plot(x, a*x*(1-x), "-b")

plt.plot([first_X, first_X], [0, ans[1]], "-r")
for i in range(T-1):
    plt.plot([ans[i], ans[i+1]], [ans[i+1], ans[i+1]], "-r")
    plt.plot([ans[i+1], ans[i+1]], [ans[i+1], ans[i+2]], "-r")

plt.xlabel("x_n")
plt.ylabel("x_(n+1)")
plt.title("a = "+str(a))
plt.show()
